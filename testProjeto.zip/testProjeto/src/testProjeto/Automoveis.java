package testProjeto;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Automoveis extends AutomoveisInfo {
	private static final DecimalFormat df = new DecimalFormat("0.00");
	
	public Automoveis(String chassi, String placa, int numFabri, String modelo, String cor, double valorDia) {
		super(chassi, placa, numFabri, modelo, cor, valorDia);
		// TODO Auto-generated constructor stub
	}

	public static void carrosSimples() {
		AutomoveisInfo hb20 = new AutomoveisInfo("121212", "12345", 123, "speed", "vermelho", 15.5 );
		System.out.printf("chassi �: "+ hb20.getChassi() 
		+ "%nsua cor �: " + hb20.getCor() 
		+ "%nsua placa �: " + hb20.getPlaca() 
		+ "%ncalor diario R$" + df.format(hb20.getValorDia())); 
		
	}
 
}
