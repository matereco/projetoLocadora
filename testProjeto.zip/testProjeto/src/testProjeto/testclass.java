package testProjeto;

public class testclass extends Automoveis {

	public testclass(String chassi, String placa, int numFabri, String modelo, String cor, double valorDia) {
		super(chassi, placa, numFabri, modelo, cor, valorDia);
		// TODO Auto-generated constructor stub
	}
	

	public static void main(String[] args) {
		
		
		
		carrosSimples();
		
	
	
		
		
	}

}
